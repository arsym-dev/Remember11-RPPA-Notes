#!/usr/bin/perl
use strict;
#my @dat;

my %single_bytes = (); # Maps SJIS bytes to escaped UTF characters
my %double_bytes = (); # Maps SJIS bytes to escaped UTF characters
my %reverse_lookup = (); # Maps UTF character to SJIS bytes

my %hw = ();

sub map_hw {
    my ($start, $str) = @_;
    for (my $i = 0; $i < length ($str); ++ $i) {
	my $n = $start + $i;
	#$hw{(substr ($str, $i, 1))} = chr ($n >> 8). chr ($n & 0xff);
	$hw{(substr ($str, $i, 1))} = pack ("n", $n);
    }
}

sub hw_to_fw {
    return join ("", map { $hw{$_} } split //, $_[0])."\0";
}


if (1) {
    map_hw (0x8143, ",. :;?!");
    map_hw (0x8140, " ");
    map_hw (0x8169, "()");
    map_hw (0x816D, "[]{}");
    map_hw (0x824f, "0123456789");
    map_hw (0x8260, join ("", map { chr ($_) } ord ("A")..ord("Z")));
    map_hw (0x8281, join ("", map { chr ($_) } ord ("a")..ord("z")));

    local @ARGV = ('cp932.txt');

    my $d = '[0-9A-F]';
    my $d2 = "0x(${d}${d})";
    my $d4 = "0x(${d}${d}${d}${d})";

    while (<>) {
	$_ =~ s/#.*//;
	next if ($_ =~ /^\s*$/);
	
	if ($_ =~ /^$d2\s+$d4\s$/o) {
	    $single_bytes{(pack ('c', hex ($1)))} = chr(hex($2));
	    $reverse_lookup{(chr(hex($2)))} = pack ('c', hex ($1));
	} elsif ($_ =~ /^$d4\s+$d4\s$/o) {
	    $double_bytes{(pack ('n', hex ($1)))} = chr(hex($2));
	    $reverse_lookup{(chr(hex($2)))} = pack ('n', hex ($1));
	} elsif ($_ =~ /^$d2\s*$/o) {
	} else {
	    print "Bad line '$_'\n";
	}
    }
    $single_bytes{('"')} = '\"';
    $double_bytes{("\x87S")} = '\x01';
    $double_bytes{("\x87T")} = '\x02';
    $double_bytes{("\x87U")} = '\x03';
    $reverse_lookup{("\x01")} = "\x87S";
    $reverse_lookup{("\x02")} = "\x87T";
    $reverse_lookup{("\x03")} = "\x87U";


    #$double_bytes(("
    #foreach (keys %single_bytes) {
    #	$reverse_lookup{($single_bytes{$_})} = $_;
    #}
    #foreach (keys %double_bytes) {
    #	$reverse_lookup{($double_bytes{$_})} = $_;
    #}
}

sub utf_to_sjis {
    my $rv = '';
    for (my $i = 0; $i < length ($_[0]); ++ $i) {
	if (defined $reverse_lookup{(substr ($_[0], $i, 1))}) {
	    $rv .= $reverse_lookup{(substr ($_[0], $i, 1))};
	} else {
	    printf STDERR ("bad character %04x in ", ord (substr ($_[0], $i, 1)));
	    for (my $j = 0; $j < length ($_[0]); ++ $j) {
		printf STDERR ("%x ", ord (substr ($_[0], $j, 1)));
	    }
	    print STDERR "\n";
	}
    }
    return $rv;
}

sub sjis_to_utf {
    my $rv = '';
    #my $ct = 0;
    for (my $i = 0; $i < length ($_[0]); ++ $i) {
	#my $b1 = $single_bytes{(substr($_[0], $i, 1))};
	#my $b2 = $double_bytes{(substr($_[0], $i, 2))};
	#$rv .= '-';
	if (defined $single_bytes{(substr($_[0], $i, 1))}) { 
	    $rv .= $single_bytes{(substr($_[0], $i, 1))};
	    #++ $ct;
	} elsif (defined $double_bytes{(substr($_[0], $i, 2))}) {
	    $rv .= $double_bytes{(substr($_[0], $i, 2))};
	    ++ $i;
	    #++ $ct;
	} else {
	    if ($i + 1 == length ($_[0])) {
		printf STDERR ("Bad character %02x.\n", unpack ('C', substr ($_[0], $i, 1)));
	    } else {
		printf STDERR ("Bad character %04x.\n", unpack ('n', substr ($_[0], $i, 2)));
	    }
	    #$ct += 100;
	}
    }
    #print $ct, ".\n";
    return $rv;
}

#binmode STDOUT, ":utf8";
#print sjis_to_utf ("¥x82¥x81¥x82¥x90¥x82¥x90¥x82¥x81¥x82¥x92¥x82¥x85¥x82¥x8e¥x82¥x94¥x81¥x40¥x82¥x4f.¥n");
#my $str = "\x82\x81\x82\x90\x82\x90\x82\x81\x82\x92\x8\x82\x8e\x82\x94\x81\x40\x82\x4f";
#my $str = "\x82\x81\x82\x90\x82\x90\x82\x81\x82\x92\x82\x85\x82\x8e\x82\x94\x81\x40\x82\x4f";
#print $str, ".\n";
#print sjis_to_utf ($str), ".\n";
#print sjis_to_utf ("\x82\x81\x82\x90\x82\x90\x82\x81\x82\x92\x8\x82\x8e\x82\x94\x81\x40\x82\x4f"), ".\n";
    
#print utf_to_sjis (sjis_to_utf ($str)), ".\n";
