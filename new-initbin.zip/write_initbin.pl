#!/usr/bin/perl

use strict;
use Encode qw/encode decode/;
require 'myinitbin.pl';
require 'sjis.pl';

sub MAKE_BASE_DATA       { return bless [ @_ ], 'BASE_DATA'; }
sub MAKE_DWORDS          { return bless [ @_ ], 'DWORDS'; }
sub MAKE_JUKEBOX_DATA    { return bless [ @_ ], 'JUKEBOX_DATA'; }
sub MAKE_JUKEBOX_ITEM    { return bless [ @_ ], 'JUKEBOX_ITEM'; }
sub MAKE_RAW             { return bless [ @_ ], 'RAW'; }
sub MAKE_STRING_TABLE    { return bless [ @_ ], 'STRING_TABLE'; }
sub MAKE_TABLE_5C        { return bless [ @_ ], 'TABLE_5C'; }
sub MAKE_TABLE_5C_MEMBER { return bless [ @_ ], 'TABLE_5C_MEMBER'; }
sub MAKE_TABLE_64        { return bless [ @_ ], 'TABLE_64'; }
sub MAKE_TABLE_64_MEMBER { return bless [ @_ ], 'TABLE_64_MEMBER'; }
sub MAKE_TIPS_DATA       { return bless [ @_ ], 'TIPS_DATA'; }
sub MAKE_COMMENT         { return (); }

my %j2e = ();
if (1) {
    local @ARGV = ('R11_init.txt');
    my @tmp = <>;
    while (@tmp) {
	while ($tmp[0] =~ m|^\s*$| || $tmp[0] =~ m|^\s*//|) {
	    shift @tmp;
	}
	last if (@tmp == 0);
	my $jline = shift @tmp;
	chomp $jline;
	die "bad convert file" if $tmp[0] =~ m|^\s*$| || $tmp[0] =~ m|^\s*//|;
	my $eline = '';
	while ($tmp[0] !~ /^\s*$/) {
	    chomp $tmp[0];
	    if ($tmp[0] =~ m|^\s*//|) {
		shift @tmp;
	    } else {
		$eline = $eline . '%N' . shift @tmp;
	    }
	}
	$eline = substr ($eline, 2);
	#my $eline = shift @tmp;
	#chomp $eline;
	$j2e{$jline} = $eline;
	#print "Added conversion '$jline' '$eline'.\n";
    }
}


my %write_data = ();
my $write_pointer = 0;
my @write_queue = ();

sub write_data {
    $write_data{$write_pointer} = $_[0];
    $write_pointer += length ($_[0]);
    #printf ("Advancing write point by %d to %08x\n", length($_[0]), $write_pointer);
}
sub write_dword {
    write_data (pack ("V", $_[0]));
}
sub write_dword_at {
    $write_data{($_[1])} = pack ("V", $_[0]);
}
sub write_null {
    write_data ("\0\0\0\0");
}
sub dword_align {
    while ($write_pointer % 4 != 0) {
	write_data ("\x90");
    }
}
sub enqueue_pointer {
    #printf ("Enqueing pointer to %s at %08x.\n", ref $_[0], $write_pointer);
    push @write_queue, $write_pointer;
    push @write_queue, $_[0];
    write_data ("\xde\xad\xbe\xef");
}

#my %dword_aligned = map { $_ => 1 } qw/DWORDS STRING_TABLE JUKEBOX_DATA TABLE_5C_MEMBER TABLE_5C TABLE_64 TABLE_64_MEMBER/;
sub write_object {
    my $r = ref $_[0];
    #print "Writing object of type $r.\n";
    #if (defined $dword_aligned{$r}) { dword_align(); }
    if (defined $r && $r ne 'RAW') { dword_align(); }
    my $rv = $write_pointer;

    if ($r eq '') {
	my $line = $_[0];
	if (defined $j2e{$line}) {
	    print "Found conversion $line to $j2e{$line}.\n";
	    $line = $j2e{$line};
	}
	write_data (utf_to_sjis (decode ("utf8", $line))."\0");
	#write_data (utf_to_sjis (decode ("utf8", $_[0]))."\0");
    } elsif ($r eq 'DWORDS') {
	write_data (pack ('V*', @{$_[0]}));
    } elsif ($r eq 'STRING_TABLE') {
	local $_;
	foreach (@{$_[0]}) {
	    enqueue_pointer ($_);
	}
	write_null ();
    } elsif ($r eq 'BASE_DATA') {
	local $_;
	foreach (@{$_[0]}) {
	    enqueue_pointer ($_);
	}	    
    } elsif ($r eq 'JUKEBOX_ITEM') {
	die "FALLTHROUGH";
    } elsif ($r eq 'JUKEBOX_DATA') {
	local $_;
	foreach (@{$_[0]}) {
	    enqueue_pointer ($_->[0]);
	    enqueue_pointer ($_->[1]);
	    enqueue_pointer ($_->[2]);
	    write_object ($_->[3]);
	}
	write_null();
    } elsif ($r eq 'RAW') {
	write_data ($_[0]->[0]);
    } elsif ($r eq 'TABLE_5C') {
	local $_;
	foreach (@{$_[0]}) {
	    enqueue_pointer ($_);
	}
	write_null();
    } elsif ($r eq 'TABLE_5C_MEMBER') {
	#print length ($_[0][0]),".\n";
	#print join (" ", @{$_[0]}), ".\n"; 
	#write_data ($_->[0][0]);
	for (my $i = 0; $i < 60; $i += 3) {
	    #print $_
	    #printf ("%x ", length ($_[0]->[$i][0]));
	    write_object ($_[0]->[$i]);
	    #write_data ($_[0]->[$i][0]);
	    enqueue_pointer ($_[0]->[$i+1]);
	    enqueue_pointer ($_[0]->[$i+2]);
	}
	#print ".\n";
    } elsif ($r eq 'TABLE_64') {
	foreach (@{$_[0]}) {
	    #print $_, ".\n";
	    enqueue_pointer ($_);
	    write_dword ((scalar @$_) / 2);
	}
	write_null();
    } elsif ($r eq 'TABLE_64_MEMBER') {
	local $_;
	#print "TABLE_64_MEMBER (", $_[0], ")\n";
	#foreach (@{$_[0]}) {
	#    enqueue_pointer ($_->[0]);
	#    write_dword ($_->[1]);
	#}
	#print "[", join (" ", @{$_[0]}), "]\n";
	for (my $i = 0; $i < @{$_[0]}; $i += 2) {
	    enqueue_pointer ($_[0]->[$i]);
	    write_dword ($_[0]->[$i+1]);
	}
    } elsif ($r eq 'TIPS_DATA') {
	local $_;
	foreach (@{$_[0]}) {
	    enqueue_pointer ($_);
	}
	write_null();
    } else {
	#print STDERR "Bad object type ".$r.".\n";
	print "Bad object type ".$r.":".length($r).".\n";
    }
    return $rv;
}

write_object (get_data());
while (@write_queue) {
    my $dest_place = shift @write_queue;
    my $dest_obj = shift @write_queue;
    #printf ("dequeing pointer to %s at %08x.\n", ref $dest_obj, $dest_place);
    my $obj_addr = write_object ($dest_obj);
    #printf ("dequeing pointer to %s at %08x : %08x.\n", 
    #	    ref $dest_obj, $dest_place, $obj_addr);
    write_dword_at ($obj_addr, $dest_place);
}

open OFH, ">init.unbip.rp";
my $out_ptr = 0;
my $pad_count = 0;
foreach my $addr (sort { $a <=> $b } keys %write_data) {
    while ($out_ptr < $addr) {
	print OFH "\x90";
	++ $pad_count;
    }
    if ($out_ptr > $addr) {
	die "OVERFLOW at $addr : $out_ptr";
    }
    my $item = $write_data{$addr};
    print OFH $item;
    $out_ptr += length ($item);
}
close OFH;
system ("r11_tr/compressbip", "init.unbip.rp", "init.rp");
print "Total of $pad_count padding bytes\n";
